from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import random
import os

NAME = ["SMITH", "JOHNSON", "WILLIAMS", "BROWN", "JONES", "MILLER", "DAVIS", "GARCIA", "RODRIGUEZ", "WILSON", "MARTINEZ", "ANDERSON", "TAYLOR", "THOMAS", "HERNANDEZ", "MOORE", "MARTIN", "JACKSON", "THOMPSON", "WHITE", "LOPEZ", "LEE", "GONZALEZ", "HARRIS", "CLARK", "LEWIS", "ROBINSON", "WALKER", "PEREZ", "HALL", "YOUNG", "ALLEN", "SANCHEZ", "WRIGHT", "KING", "SCOTT", "GREEN", "BAKER", "ADAMS", "NELSON", "HILL", "RAMIREZ", "CAMPBELL", "MITCHELL", "ROBERTS", "CARTER", "PHILLIPS", "EVANS", "TURNER", "TORRES", "PARKER", "COLLINS", "EDWARDS", "STEWART", "FLORES", "MORRIS", "NGUYEN", "MURPHY", "RIVERA", "COOK", "ROGERS", "MORGAN", "PETERSON", "COOPER", "REED", "BAILEY", "BELL", "GOMEZ", "KELLY", "HOWARD", "WARD", "COX", "DIAZ", "RICHARDSON", "WOOD", "WATSON", "BROOKS", "BENNETT", "GRAY", "JAMES", "REYES", "CRUZ", "HUGHES", "PRICE", "MYERS", "LONG", "FOSTER", "SANDERS", "ROSS", "MORALES", "POWELL", "SULLIVAN", "RUSSELL", "ORTIZ", "JENKINS", "GUTIERREZ", "PERRY", "BUTLER", "BARNES", "FISHER", "HENDERSON", "COLEMAN", "SIMMONS", "PATTERSON", "JORDAN", "REYNOLDS", "HAMILTON", "GRAHAM", "KIM", "GONZALES", "ALEXANDER", "RAMOS", "WALLACE"]
URLs = {}
URLs["login"] = "https://e5.onthehub.com/WebStore/Security/Signin.aspx?ws=ff0962dd-978c-e011-969d-0030487d8897&vsro=8"
URLs["account_details"] = "https://e5.onthehub.com/WebStore/Account/YourAccountDetails.aspx?ws=ff0962dd-978c-e011-969d-0030487d8897&vsro=8"
URLs["account_products"] = "https://e5.onthehub.com/WebStore/Account/YourAccount.aspx?ws=ff0962dd-978c-e011-969d-0030487d8897&vsro=8"

username = "hv3202@outlook.com"
password = "8gAdl4"

xpaths = { 'login_username' : '//*[@id="ctl00_cpContent_txtUserName"]',
           'login_password' : '//*[@id="ctl00_cpContent_txtPassword"]',
           'login_submit'   : '//*[@id="ctl00_cpContent_btnSignIn"]',
           'cart_add'       : '//*/span[contains(text(), "Add to Cart")]',
           'account_first'  : '//*[@id="ctl00_cpContent_ucAccountDetails_efvPerson_pnPersonName_txtFirstName"]',
           'account_last'   : '//*[@id="ctl00_cpContent_ucAccountDetails_efvPerson_pnPersonName_txtLastName"]',
           'account_submit' :'//*[@id="ctl00_cpContent_btnSave"]'
         }

def main(u, p):

    mydriver = webdriver.Firefox(executable_path=r'./geckodriver.exe')
    mydriver.implicitly_wait(5)
    # Login
    print("Logging in as {}".format(u))

    mydriver.get(URLs["login"])
    for i in range(1, 4):
        mydriver.find_element_by_xpath(xpaths['login_username']).clear()
        mydriver.find_element_by_xpath(xpaths['login_password']).clear()
        mydriver.find_element_by_xpath(xpaths['login_username']).send_keys(u)
        mydriver.find_element_by_xpath(xpaths['login_password']).send_keys(p)
        mydriver.find_element_by_xpath(xpaths['login_submit']).click()
        mydriver.implicitly_wait(5)
        if "ProductsByMajorVersionList.aspx" in mydriver.current_url:
            break
        else:
            print("Retrying login ... ({})".format(i))

    if not "ProductsByMajorVersionList.aspx" in mydriver.current_url:
        return False
    else:
        print("Logged in")

    # Products page
    print("Listing products")
    productList = []
    productWrapperList = mydriver.find_elements_by_class_name("product-wrapper");
    for _productWrapper in productWrapperList:
        _product = _productWrapper.find_element_by_xpath('.//a/div/div[@class="product-name"]/bdi/span').text
        _url = _productWrapper.find_element_by_xpath('.//a[@href]').get_attribute("href")
        productList.append((_product, _url))

    # add products to cart
    for _p, _l in productList:
        print("Adding product to cart: {}".format(_p))
        mydriver.get(_l)
        addToCartButtonSpan = mydriver.find_element_by_xpath(xpaths['cart_add'])
        addToCartButton = addToCartButtonSpan.find_element_by_xpath("..")
        try:
            WebDriverWait(mydriver, 10).until(EC.invisibility_of_element_located((By.ID, "kvloadingindicator")))
            print "kv loading disapeared"
            addToCartButton.click()

        except Exception as e:
            print e
        finally:
            print("Product added")

    # update user information
    for i in range(1, 3):
        mydriver.get(URLs["account_details"])
        if mydriver.find_element_by_xpath(xpaths['account_first']).get_attribute('value') == "":
            print("Updating user info")
            mydriver.find_element_by_xpath(xpaths['account_first']).clear()
            mydriver.find_element_by_xpath(xpaths['account_last']).clear()
            mydriver.find_element_by_xpath(xpaths['account_first']).send_keys(random.choice(NAME))
            mydriver.find_element_by_xpath(xpaths['account_last']).send_keys(random.choice(NAME))
            mydriver.find_element_by_xpath(xpaths['account_submit']).click()
            mydriver.implicitly_wait(5)
        else:
            break
    # checkout
    exit()

    # get keys
    mydriver.get(URLs["account_products"])

    # log out

if __name__ == '__main__':
    main(username, password)


